export function extractGreenhouseDetails() {
  // TODO: Implement extraction logic for Greenhouse
  return {
    jobTitle: jobTitle,
    companyInfo: companyInfo,
    url: window.location.href,
    jobDescription: jobDescription
  };
}